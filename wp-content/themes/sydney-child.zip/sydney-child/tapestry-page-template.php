<?php

/*
 Template Name: Tapestry Page Template
 */

get_header(); ?>

	<div id="primary" class="content-area col-md-12">
		<main id="main" class="post-wrap" role="main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php get_template_part( 'content', 'page' ); ?>

				<?php
					// If comments are open or we have at least one comment, load up the comment template
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;
				?>

			<?php endwhile; // end of the loop. ?>
			
            <div id="tapestry"></div>

            <link crossorigin="anonymous" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" rel="stylesheet" />
			<link href="/wp-content/themes/sydney-child/tapestry/home/tapestry.css" rel="stylesheet" />
            <link href="/wp-content/themes/sydney-child/tapestry/home/jquery-ui.min.css" rel="stylesheet" />
            
            <script src="/wp-content/themes/sydney-child/tapestry/home/jquery.min.js" type="application/javascript"></script>
            <script src="/wp-content/themes/sydney-child/tapestry/home/jquery-ui.min.js" type="application/javascript"></script>
            <script src="/wp-content/themes/sydney-child/tapestry/home/jscookie.js" type="application/javascript"></script>
            <script src="/wp-content/themes/sydney-child/tapestry/home/d3.v5.min.js" type="application/javascript"></script>
            <script src="/wp-content/themes/sydney-child/tapestry/home/detect-zoom.js" type="application/javascript"></script>
            <script src="/wp-content/themes/sydney-child/tapestry/home/tapestry.js"></script>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); ?>
