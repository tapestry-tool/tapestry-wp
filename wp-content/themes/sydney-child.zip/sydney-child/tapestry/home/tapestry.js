(function(){

    /****************************************************
     * CONSTANTS AND GLOBAL VARIABLES
     ****************************************************/

    var // declared
        PROGRESS_THICKNESS = 20,
        LINK_THICKNESS = 10,
        NORMAL_RADIUS = 140,
        ROOT_RADIUS_DIFF = 50,
        GRANDCHILD_RADIUS_DIFF = -100,
        NODE_IMAGE_HEIGHT = 330,
        NODE_IMAGE_WIDTH = 700,
        TRANSITION_DURATION = 800,
        COLOR_STROKE = "#E57D6C",
        COLOR_GRANDCHILD = "#999",
        COLOR_LINK = "#C1D5DF",
		numColumns = 5,
		numRows = 4;

    var // calculated
        BROWSER_WIDTH = Math.max(document.documentElement.clientWidth, window.innerWidth || 0) - 60,
        BROWSER_HEIGHT = Math.max(document.documentElement.clientHeight, window.innerHeight || 0) - 60,
        SVG_SCALE = (BROWSER_WIDTH < 800 || BROWSER_HEIGHT < 800) ? 2 : 2,
		MAX_RADIUS;
	
	MAX_RADIUS = BROWSER_WIDTH / numColumns;
	if ( (BROWSER_HEIGHT / numRows) < MAX_RADIUS) {
		MAX_RADIUS = BROWSER_HEIGHT / numRows;
	}
	
	MAX_RADIUS -= 10;
	ROOT_RADIUS_DIFF = MAX_RADIUS * 0.25;
	NORMAL_RADIUS = MAX_RADIUS - ROOT_RADIUS_DIFF - 30; // 30 is to count for the icon
	GRANDCHILD_RADIUS_DIFF = NORMAL_RADIUS * -0.6;
	
	var // radius-related
        INNER_RADIUS = NORMAL_RADIUS - (PROGRESS_THICKNESS / 2),
        OUTER_RADIUS = NORMAL_RADIUS + (PROGRESS_THICKNESS / 2);
	
	var nodeX_distance = (BROWSER_WIDTH - 2*MAX_RADIUS ) / (numColumns-1) * SVG_SCALE;
	if (nodeX_distance > 2.5 * MAX_RADIUS) {
		nodeX_distance = 2.5 * MAX_RADIUS;
	}
	var nodeCoordsX = [MAX_RADIUS];
	for (i=0; i<numColumns; i++) {
		nodeCoordsX.push( nodeCoordsX[i] + nodeX_distance );
	}
	
	var nodeY_distance = (BROWSER_HEIGHT - 2*MAX_RADIUS ) / (numRows-1) * SVG_SCALE * 1.5;
	if (nodeY_distance > 2.5 * MAX_RADIUS) {
		nodeY_distance = 2.5 * MAX_RADIUS;
	}
	var nodeCoordsY = [MAX_RADIUS];
	for (i=0; i<numRows; i++) {
		nodeCoordsY.push( nodeCoordsY[i] + nodeY_distance );
	}

    var root, svg, links, nodes,            // Basics
        path, pieGenerator, arcGenerator,   // Donut
        linkForce, collideForce, force,     // Force
        tapestryWidth, tapestryHeight;

    /****************************************************
     * INITIALIZATION
     ****************************************************/

//---------------------------------------------------
// 1. GET THE DATA READY
//---------------------------------------------------
	
// TODO: Import data from an external json file instead
    var dataset = {
        "rootId": 1,
        "nodes": [
            {
                "id": 1,
                "nodeType": "",
                "title": "TAPESTRY",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "mediaDuration": 0,
                "typeId": 1,
                "group": 1,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0},
                        {"group": "unviewed", "value": 1}
                    ]
                },
                "fx": nodeCoordsX[2],
                "fy": nodeCoordsY[2]
            },
            {
                "id": 2,
                "nodeType": "",
                "title": "ABOUT",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 2,
                "group": 2,
                "popupId": 56,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.2},
                        {"group": "unviewed", "value": 0.8}
                    ]
                },
                "fx": nodeCoordsX[3],
                "fy": nodeCoordsY[1]
            },
            {
                "id": 3,
                "nodeType": "",
                "title": "REFERENCES",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 69,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0},
                        {"group": "unviewed", "value": 1.00}
                    ]
                },
                "fx": nodeCoordsX[1],
                "fy": nodeCoordsY[3]
            },
            {
                "id": 4,
                "nodeType": "",
                "title": "PROGRESS",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 118,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0},
                        {"group": "unviewed", "value": 1.00}
                    ]
                },
                "fx": nodeCoordsX[3],
                "fy": nodeCoordsY[2]
            },
            {
                "id": 5,
                "nodeType": "",
                "title": "USE CASES",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
				"popupId": 250,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0},
                        {"group": "unviewed", "value": 1.00}
                    ]
                },
                "fx": nodeCoordsX[2],
                "fy": nodeCoordsY[1]
            },
            {
                "id": 6,
                "nodeType": "",
                "title": "BLOG",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0},
                        {"group": "unviewed", "value": 1.00}
                    ]
                },
                "fx": nodeCoordsX[0],
                "fy": nodeCoordsY[2]
            },
            {
                "id": 7,
                "nodeType": "",
                "title": "YEAR 1",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 119,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0},
                        {"group": "unviewed", "value": 1.00}
                    ]
                },
                "fx": nodeCoordsX[2],
                "fy": nodeCoordsY[3]
            },
            {
                "id": 8,
                "nodeType": "",
                "title": "YEAR 2",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "popupId": 119,
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[3],
                "fy": nodeCoordsY[3]
            },
            {
                "id": 9,
                "nodeType": "",
                "title": "MODULES",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[4],
                "fy": nodeCoordsY[2]
            },
            {
                "id": 10,
                "nodeType": "",
                "title": "PEOPLE",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
				"popupId": 261,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[4],
                "fy": nodeCoordsY[1]
            },
            {
                "id": 11,
                "nodeType": "",
                "title": "PI & CO-APPLICANTS",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 114,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[5],
                "fy": nodeCoordsY[0]
            }
            ,
            {
                "id": 12,
                "nodeType": "",
                "title": "ADVISORY BOARD MEMBERS",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 117,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[5],
                "fy": nodeCoordsY[1]
            },
            {
                "id": 13,
                "nodeType": "",
                "title": "EMPLOYEES",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 116,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[4],
                "fy": nodeCoordsY[0]
            },
            {
                "id": 14,
                "nodeType": "",
                "title": "ALUMNI",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "popupId": 115,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[5],
                "fy": nodeCoordsY[2]
            },
            {
                "id": 15,
                "nodeType": "",
                "title": "ICUS",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[5],
                "fy": nodeCoordsY[3]
            },
            {
                "id": 16,
                "nodeType": "",
                "title": "DISABILITIES",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[4],
                "fy": nodeCoordsY[3]
            },
            {
                "id": 17,
                "nodeType": "",
                "title": "TAPESTRY TOOL",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[2],
                "fy": nodeCoordsY[0]
            },
            {
                "id": 18,
                "nodeType": "",
                "title": "USER TRAINING",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[1],
                "fy": nodeCoordsY[0]
            },
            {
                "id": 19,
                "nodeType": "",
                "title": "TIMELINE",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
				"popupId": 263,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[3],
                "fy": nodeCoordsY[0]
            },
			{
                "id": 20,
                "nodeType": "",
                "title": "CONTACT US",
                "imageURL": "",
                "mediaType": "video",
                "mediaFormat": "mp4",
                "typeId": 1,
                "group": 2,
				"popupId": 108,
                "typeData": {
                    "progress": [
                        {"group": "viewed", "value": 0.5},
                        {"group": "unviewed", "value": 0.5}
                    ]
                },
                "fx": nodeCoordsX[1],
                "fy": nodeCoordsY[1]
            }
        ],
        "links": [
            {"source": 1, "target": 2, "value": 1, "type": ""},
            {"source": 1, "target": 3, "value": 1, "type": ""},
            {"source": 1, "target": 4, "value": 1, "type": ""},
            {"source": 1, "target": 6, "value": 2, "type": ""},
			{"source": 1, "target": 20, "value": 1, "type": ""},
            {"source": 2, "target": 5, "value": 2, "type": ""},
            {"source": 2, "target": 9, "value": 2, "type": ""},
            {"source": 2, "target": 10, "value": 2, "type": ""},
            {"source": 2, "target": 17, "value": 2, "type": ""},
            {"source": 2, "target": 19, "value": 2, "type": ""},
            {"source": 4, "target": 7, "value": 2, "type": ""},
            {"source": 4, "target": 8, "value": 2, "type": ""},
            {"source": 9, "target": 15, "value": 2, "type": ""},
            {"source": 9, "target": 16, "value": 2, "type": ""},
            {"source": 10, "target": 11, "value": 2, "type": ""},
            {"source": 10, "target": 12, "value": 2, "type": ""},
            {"source": 10, "target": 13, "value": 2, "type": ""},
            {"source": 10, "target": 14, "value": 2, "type": ""},
            {"source": 17, "target": 18, "value": 2, "type": ""}
        ]
    };

    root = dataset.rootId;

    setNodeTypes(dataset.rootId);
    setLinkTypes(dataset.rootId);

//---------------------------------------------------
// 2. CREATE THE SVG OBJECTS
//---------------------------------------------------

// this is needed to calculate the bounded coordinates
    tapestryWidth = BROWSER_WIDTH * SVG_SCALE;
    tapestryHeight = BROWSER_HEIGHT * SVG_SCALE;

    svg = createSvgContainer("tapestry");
    links = createLinks();
    nodes = createNodes();

    filterLinks();

    buildNodeContents();

//---------------------------------------------------
// 3. START THE FORCED GRAPH
//---------------------------------------------------

    console.log('test');

    startForce();

    /****************************************************
     * D3 RELATED FUNCTIONS
     ****************************************************/

    /* Define forces that will determine the layout of the graph */
    function startForce() {
        linkForce = d3.forceLink()
            .id(function (d) {
                return d.id;
            })
            .distance(MAX_RADIUS / 3);

        collideForce = d3.forceCollide(
            function (d) {
                return getRadius(d) * 1.5;
            });

        force = d3.forceSimulation()
            .force("link", linkForce)
            .force('collide', collideForce)
            .force('center', d3.forceCenter(tapestryWidth / 2, tapestryHeight / 2));

        force
            .nodes(dataset.nodes)
            .on("tick", ticked);

        force
            .force("link")
            .links(dataset.links);
    }

//Resize all nodes, where id is now the root
    function resizeNodes(id) {

        setNodeTypes(id);
        setLinkTypes(id);
        filterLinks();

        rebuildLinks();
        rebuildNodeContents();

        /* Restart force */
        startForce();
    }

    function ticked() {
        links
            .attr("x1", function (d) {
                return getBoundedCoord(d.source.x, tapestryWidth);
            })
            .attr("y1", function (d) {
                return getBoundedCoord(d.source.y, tapestryHeight);
            })
            .attr("x2", function (d) {
                return getBoundedCoord(d.target.x, tapestryWidth);
            })
            .attr("y2", function (d) {
                return getBoundedCoord(d.target.y, tapestryHeight);
            });
        nodes
            .attr("cx", function (d) {
                return getBoundedCoord(d.x, tapestryWidth);
            })
            .attr("cy", function (d) {
                return getBoundedCoord(d.y, tapestryHeight);
            })
            .attr("transform", function (d) {
                return "translate(" + getBoundedCoord(d.x, tapestryWidth) + "," + getBoundedCoord(d.y, tapestryHeight) + ")";
            });
    }

    function dragstarted(d) {
        if (!d3.event.active) force.alphaTarget(0.2).restart();
        d.fx = getBoundedCoord(d.x, tapestryWidth);
        d.fy = getBoundedCoord(d.y, tapestryHeight);
    }

    function dragged(d) {
        d.fx = d3.event.x;
        d.fy = d3.event.y;
    }

    function dragended(d) {
//    if (!d3.event.active) simulation.alphaTarget(0);
        if (!d3.event.active) force.alphaTarget(0);
        d.fx = d.x;
        d.fy = d.y;
    }

    function createSvgContainer(containerId) {
        return d3.select("#"+containerId)
            .append("svg:svg")
            .attr("viewBox", "0 0 " + tapestryWidth + " " + tapestryHeight)
            .attr("preserveAspectRatio", "xMidYMid meet")
            .append("svg:g")
            .attr("transform", "translate(-20, 0)");
    }

    function createLinks() {
        /* Need to remove old links when redrawing graph */
        return svg.append("svg:g")
            .attr("class", "links")
            .selectAll("line")
            .data(dataset.links)
            .enter()
            .append("line")
            .attr("stroke", function (d) {
                if (d.type === "grandchild") return COLOR_GRANDCHILD;
                else return COLOR_LINK;
            })
            .attr("stroke-width", LINK_THICKNESS);
    }

    function createNodes() {
        /* Need to remove old nodes when redrawing graph */
        return svg.selectAll("g.node")
            .data(dataset.nodes)
            .enter()
            .append("svg:g")
            .attr("class", "node")
            .attr("id", function (d) {
                return "node-" + d.id;
            });
    }

// TODO: Get rid of this function (use buildNodeContents and rebuildNodeContents instead)
    function filterLinks() {
        var linksToHide = links.filter(function (d) {
            var sourceId, targetId;
            if (typeof d.source === 'number' && typeof d.target === 'number') {
                sourceId = d.source;
                targetId = d.target;
            } else if (typeof d.source === 'object' && typeof d.target === 'object') {
                sourceId = d.source.id;
                targetId = d.target.id;
            }

            var shouldRender = false;
            if (sourceId === root || targetId === root) {
                shouldRender = true;
            } else if (getChildren(root).indexOf(sourceId) > -1 || getChildren(root).indexOf(targetId) > -1) {
                shouldRender = true;
            }
            return !shouldRender;
        });

        var linksToShow = links.filter(function (d) {
            var sourceId, targetId;
            if (typeof d.source === 'number' && typeof d.target === 'number') {
                sourceId = d.source;
                targetId = d.target;
            } else if (typeof d.source === 'object' && typeof d.target === 'object') {
                sourceId = d.source.id;
                targetId = d.target.id;
            }

            var shouldRender = false;
            if (sourceId === root || targetId === root) {
                shouldRender = true;
            } else if (getChildren(root).indexOf(sourceId) > -1 || getChildren(root).indexOf(targetId) > -1) {
                shouldRender = true;
            }

            return shouldRender;
        });

        linksToShow
            .style("display", "block");

        linksToHide
            .transition()
            .duration(TRANSITION_DURATION)
            .style("opacity", "0");

        linksToShow
            .transition()
            .duration(TRANSITION_DURATION)
            .style("opacity", "1");

        setTimeout(function(){
            linksToHide
                .style("display", "block");
        }, TRANSITION_DURATION);
    }

    /* Draws the components that make up node */
    function buildNodeContents() {

        /* Draws the circle that defines how large the node is */
        nodes.append("rect")
            .attr("class", function (d) {
                if (d.nodeType === "grandchild") return "imageContainer expandGrandchildren";
                return "imageContainer";
            })
            .attr("rx", function (d) {
                return getRadius(d);
            })
            .attr("ry", function (d) {
                return getRadius(d);
            })
            .attr("data-id", function (d) {
                return d.id;
            })
            .attr("stroke-width", function (d) {
                return PROGRESS_THICKNESS;
            })
            .attr("stroke", function (d) {
                if (d.nodeType === "")
                    return "transparent";
                else if (d.nodeType === "grandchild")
                    return COLOR_GRANDCHILD;
                else return COLOR_STROKE;
            })
            .attr("width", function (d) {
                if (d.nodeType === "") return 0;
                return getRadius(d) * 2;
            })
            .attr("height", function (d) {
                if (d.nodeType === "") return 0;
                return getRadius(d) * 2;
            })
            .attr("x", function (d) {
                return - getRadius(d);
            })
            .attr("y", function (d) {
                return - getRadius(d);
            })
            .attr("fill", function (d) {
                return "url('#node-thumb-" + d.id + "')";
            });

        nodes.append("circle")
            .attr("class", "imageOverlay")
            .attr("data-id", function (d) {
                return d.id;
            })
            .attr("stroke-width", function () {
                return PROGRESS_THICKNESS;
            })
            .attr("r", function (d) {
                return getRadius(d);
            })
            .attr("fill", function (d) {
                if (d.nodeType === "")
                    return "transparent";
                else if (d.nodeType === "grandchild")
                    return COLOR_GRANDCHILD;
                else return COLOR_STROKE;
            });

        /* Attach images to be used within each node */
        nodes.append("defs")
            .append("pattern")
            .attr("id", function (d) {
                return "node-thumb-" + d.id;
            })
            .attr("data-id", function (d) {
                return d.id;
            })
            .attr("pattenUnits", "userSpaceOnUse")
            .attr("height", 1)
            .attr("width", 1)
            .append("image")
            .attr("height", function (d) {
                if (d.nodeType === "root") {
                    return NODE_IMAGE_HEIGHT + ROOT_RADIUS_DIFF;
                } else return NODE_IMAGE_HEIGHT;
            })
            .attr("width", NODE_IMAGE_WIDTH)
            .attr("x", 0)
            .attr("y", 0)
            .attr("preserveAspectRatio", "xMinYMin")
            .attr("xlink:href", function (d) {
                return d.imageURL;
            });

        /* Add path and button */
        buildPathAndButton();

        /* Add dragging and node selection functionality to the node */
        nodes.call(d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended))
            .on("dblclick", function (d) {
                resizeNodes(d.id);
            });
    }

    function rebuildNodeContents() {

        nodes.selectAll(".imageOverlay")
            .transition()
            .duration(TRANSITION_DURATION/3)
            .attr("r", function (d) {
                return getRadius(d);
            })
            .attr("fill", function (d) {
                if (d.nodeType === "")
                    return "transparent";
                else if (d.nodeType === "grandchild")
                    return COLOR_GRANDCHILD;
                else return COLOR_STROKE;
            });

        nodes.selectAll(".imageContainer")
            .attr("class", function (d) {
                if (d.nodeType === "grandchild" || d.nodeType === "")
                    return "imageContainer expandGrandchildren";
                else return "imageContainer";
            })
            .transition()
            .duration(TRANSITION_DURATION)
            .attr("rx", function (d) {
                return getRadius(d);
            })
            .attr("ry", function (d) {
                return getRadius(d);
            })
            .attr("stroke", function (d) {
                if (d.nodeType === "")
                    return "transparent";
                else if (d.nodeType === "grandchild")
                    return COLOR_GRANDCHILD;
                else return COLOR_STROKE;
            })
            .attr("width", function (d) {
                return getRadius(d) * 2;
            })
            .attr("height", function (d) {
                return getRadius(d) * 2;
            })
            .attr("x", function (d) {
                return - getRadius(d);
            })
            .attr("y", function (d) {
                return - getRadius(d);
            })
            .attr("fill", function (d) {
                return "url('#node-thumb-" + d.id + "')";
            });

        /* Attach images to be used within each node */
        nodes.selectAll("defs")
            .selectAll("pattern")
            .selectAll("image")
            .transition()
            .duration(TRANSITION_DURATION)
            .attr("height", function (d) {
                if (d.nodeType === "root") {
                    return NODE_IMAGE_HEIGHT + ROOT_RADIUS_DIFF;
                } else return NODE_IMAGE_HEIGHT;
            });

        // Remove elements and add them back in
        nodes.selectAll("text").remove();
        nodes.selectAll(".mediaButton").remove();
        nodes.selectAll("path").remove();
        setTimeout(function(){
            buildPathAndButton();
        }, TRANSITION_DURATION);

    }

    function buildPathAndButton() {

        /* Add progress pie inside each node */
        pieGenerator = d3.pie().sort(null).value(function (d) {
            return d.value;
        });
        arcGenerator = d3.arc().startAngle(0);

        /* Update the progress pies */
        updateViewedProgress();

        nodes
            .filter(function (d) {
                return d.nodeType !== ""
            })
            .append("text")
            .attr("text-anchor", "middle")
            .attr("fill", "white")
            .attr("class", "title")
            .attr("text-anchor", "middle")
            .attr("data-id", function (d) {
                return d.id;
            })
            .text(function (d) {
                return d.title;
            })
            .attr("style", function (d) {
                return d.nodeType === "grandchild" ? "visibility: hidden" : "visibility: visible";
            })
            .call(wrapText, NORMAL_RADIUS * 2);

        nodes
            .filter(function (d) {
                return d.nodeType !== ""
            })
            .append("svg:foreignObject")
            .html(function (d) {
                return '<span id="mediaButtonIcon' + d.id + '" class="fas fa-play-circle mediaButtonIcon" onclick=\'jQuery("[data-sgpbpopupid=\\"' + d.popupId + '\\"]").click();\' data-id="' + d.id + '"><\/span>';

            })
            .attr("id", function (d) {
                return "mediaButton" + d.id;
            })
            .attr("data-id", function (d) {
                return d.id;
            })
            .attr("width", "60px")
            .attr("height", "62px")
			.attr("display", "grid")
            .attr("x", -27)
            .attr("y", function (d) {
                return -NORMAL_RADIUS - 30 - (d.nodeType === "root" ? ROOT_RADIUS_DIFF : 0);
            })
            .attr("style", function (d) {
                return d.nodeType === "grandchild" ? "visibility: hidden" : "visibility: visible";
            })
            .attr("class", "mediaButton");
    }



    function rebuildLinks() {
        links = d3.selectAll("line")
            .attr("stroke", function (d) {
                if (d.type === "grandchild") return COLOR_GRANDCHILD;
                else return COLOR_LINK;
            })
            .attr("stroke-width", LINK_THICKNESS);
    }

    function updateViewedProgress() {
        path = nodes
            .filter(function (d) {
                return d.nodeType !== ""
            })
            .selectAll("path")
            .data(function (d, i) {
                var data = d.typeData.progress;
                data.forEach(function (e) {
                    e.extra = {'nodeType': d.nodeType}
                })
                return pieGenerator(data, i);
            });

        path.transition().duration(750).attrTween("d", arcTween);

        path.enter()
            .append("path")
            .attr("fill", function (d, i) {
                if (d.data.group !== "viewed") return "transparent";
                if (d.data.extra.nodeType === "grandchild" || d.data.extra.nodeType === "")
                    return "#cad7dc";
                else return "#EFB7B7";
            })
            .attr("class", function (d) {
                if (d.data.extra.nodeType === "grandchild" || d.data.extra.nodeType === "")
                    return "expandGrandchildren";
            })
            .attr("d", function (d) {
                return arcGenerator(adjustProgressBarRadii(d));
            });
    }

    function arcTween(a) {
        const i = d3.interpolate(this._current, a);
        this._current = i(1);
        return (t) => {
            return arcGenerator(adjustProgressBarRadii(i(t)))
        };
    }

    function adjustProgressBarRadii(d) {
        var addedRadius = 0;
        var addedRadiusInner = 0;
        if (d.data.extra.nodeType === "root")
            addedRadius = ROOT_RADIUS_DIFF;
        if (d.data.extra.nodeType === "grandchild") {
            addedRadius = GRANDCHILD_RADIUS_DIFF;
            addedRadiusInner = -1 * (INNER_RADIUS + addedRadius); // set inner radius to 0
        }
        arcGenerator.innerRadius(INNER_RADIUS + addedRadius + addedRadiusInner)(d);
        arcGenerator.outerRadius(OUTER_RADIUS + addedRadius)(d);
        return d;
    }

    /****************************************************
     * HELPER FUNCTIONS
     ****************************************************/

// Finds the node index with node ID
    function findNodeIndex(id) {
        function helper(obj) {
            return obj.id == id;
        }

        return dataset.nodes.findIndex(helper);
    }

    function getBoundedCoord(coord, maxCoord) {
        return Math.max(MAX_RADIUS, Math.min(maxCoord - MAX_RADIUS, coord));
    }

    function getChildren(id) {
        var children = [];
        var dataLinks = dataset.links;
        for (var linkId in dataLinks) {
            var link = dataLinks[linkId];
            //SEARCH FOR: CURRENT_ID_NODE -> CHILD links
            if (typeof link.source === 'number' && link.source === id) {
                children.push(link.target);
            } else if (typeof link.source === 'object' && link.source.id === id) {
                children.push(link.target.id);
            }

            //SEARCH FOR: PARENT -> CURRENT_ID_NODE links;
            // These should also appear as "children" because they're adjacent to the current node
            if (typeof link.target === 'number' && link.target === id) {
                children.push(link.source);
            } else if (typeof link.target === 'object' && link.target.id === id) {
                children.push(link.source.id);
            }
        }

        return children;
    }

    function getGrandchildren(children) {
        var grandchildren = [];
        for (var childId in children) {
            var child = children[childId];
            var currentGrandchildren = getChildren(child);
            grandchildren = grandchildren.concat(currentGrandchildren);
        }

        return grandchildren;
    }

    function getRadius(d) {
        var nodeDiff;
        if (d.nodeType === "") {
            return 0;
        } else if (d.nodeType === "root") {
            nodeDiff = ROOT_RADIUS_DIFF;
        } else if (d.nodeType === "grandchild") {
            nodeDiff = GRANDCHILD_RADIUS_DIFF;
        } else nodeDiff = 0

        return NORMAL_RADIUS + nodeDiff;
    }

//Updates the data in the node for how much the video has been viewed
    function updateViewedValue(id, amountViewedTime, duration) {
        var amountViewed = amountViewedTime / duration;
        var amountUnviewed = 1.00 - amountViewed;

        var index = findNodeIndex(id);

        //Update the dataset with new values
        dataset.nodes[index].typeData.progress[0].value = amountViewed;
        dataset.nodes[index].typeData.progress[1].value = amountUnviewed;
    }

    /* For setting the "type" field of nodes in dataset */
    function setNodeTypes(rootId) {

        root = rootId;
        var children = getChildren(root),
            grandchildren = getGrandchildren(children);

        for (var i in dataset.nodes) {
            var node = dataset.nodes[i];
            var id = node.id;

            //NOTE: If there are any nodes are that fit two roles (ie: root and the grandchild),
            //      should default to being the more senior role
            if (id === root) {
                node.nodeType = "root";
            } else if (children.indexOf(id) > -1) {
                node.nodeType = "child";
            } else if (grandchildren.indexOf(id) > -1) {
                node.nodeType = "grandchild";
            } else {
                node.nodeType = "";
            }
        }
    }

    /* For setting the "type" field of links in dataset */
    function setLinkTypes(rootId) {

        root = rootId;
        var children = getChildren(root),
            grandchildren = getGrandchildren(children);

        for (var i in dataset.links) {
            var link = dataset.links[i];
            var targetId = link.target.id;

            if (targetId === root) {
                link.type = "root";
            } else if (children.indexOf(targetId) > -1) {
                link.type = "child";
            } else if (grandchildren.indexOf(targetId) > -1) {
                link.type = "grandchild";
            } else {
                link.type = "";
            }
        }
    }

})();

// Wrap function specifically for SVG text
// Found on https://bl.ocks.org/mbostock/7555321
function wrapText(text, width) {
    text.each(function (d) {
        var text = d3.select(this),
            words = text.text().split(/\s+/).reverse(),
            word,
            lines = [],
            currentLine = [],
            lineNumber = 0,
            lineHeight = 1.1, // ems
            tspan = text.text(null)
                .append("tspan")
                .attr("class", "line" + d.id)
                .attr("x", 0)
                .attr("y", 0);

        while (word = words.pop()) {
            currentLine.push(word);
            tspan.text(currentLine.join(" "));
            if (tspan.node().getComputedTextLength() > width) {
                currentLine.pop(); // Pop the last word off of the previous line
                lines.push(currentLine);
                tspan.text(currentLine.join(" "));
                currentLine = [word]; // line now becomes a new array
                lineNumber++;
                tspan = text.append("tspan")
                    .attr("class", "line" + d.id)
                    .attr("x", 0) //0 because it keeps it in the center
                    .attr("y", function() {
                        return ++lineNumber * lineHeight + "em";
                    })
                    .text(word);
            }
        }

        var midLineIndex = Math.floor(lineNumber / 4);
        var tspans = document.getElementsByClassName("line" + d.id);
        var i = 0;
        while (tspans[i] !== undefined) {
            tspans[i].setAttribute("y", (i - midLineIndex) * lineHeight + "em");
            i++;
        }
    });
}